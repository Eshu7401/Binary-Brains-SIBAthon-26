import javax.swing.*;

public class LoginGUI extends JFrame {

    public LoginGUI(){

        setTitle("Login");
        setSize(300,220);
        setLayout(null);

        JLabel l1=new JLabel("Email");
        l1.setBounds(30,40,80,30);
        add(l1);

        JTextField email=new JTextField();
        email.setBounds(120,40,120,30);
        add(email);

        JLabel l2=new JLabel("Password");
        l2.setBounds(30,80,80,30);
        add(l2);

        JPasswordField pass=new JPasswordField();
        pass.setBounds(120,80,120,30);
        add(pass);

        JButton login=new JButton("Login");
        login.setBounds(90,140,100,30);
        add(login);

        login.addActionListener(e->{

            String data[]=new LoginDAO().login(
                    email.getText(),
                    new String(pass.getPassword())
            );

            if(data==null){
                JOptionPane.showMessageDialog(null,"Invalid Login");
            }

            else if(data[1].equals("Admin")){
                new AdminDashboard(data[0],data[1],data[2]);
                dispose();
            }

            else if(data[1].equals("Teacher")){
                new TeacherDashboard(data[0],data[1],data[2]);
                dispose();
            }

            else if(data[1].equals("Student")){
                new StudentDashboard(data[0],data[1],data[2]);
                dispose();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
