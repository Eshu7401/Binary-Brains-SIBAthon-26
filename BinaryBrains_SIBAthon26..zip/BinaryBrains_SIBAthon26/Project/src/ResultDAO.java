import java.sql.*;

public class ResultDAO {

    public void saveResult(String email,String title,int marks){

        try{
            Connection conn=DBConnection.getConnection();

            String check="SELECT * FROM result WHERE email=? AND title=?";
            PreparedStatement pst1=conn.prepareStatement(check);

            pst1.setString(1,email.trim());
            pst1.setString(2,title.trim());

            ResultSet rs=pst1.executeQuery();

            if(rs.next()){

                String update="UPDATE result SET marks=? WHERE email=? AND title=?";
                PreparedStatement pst2=conn.prepareStatement(update);

                pst2.setInt(1,marks);
                pst2.setString(2,email.trim());
                pst2.setString(3,title.trim());
                pst2.executeUpdate();
            }
            else{

                String insert="INSERT INTO result(email,title,marks) VALUES(?,?,?)";
                PreparedStatement pst3=conn.prepareStatement(insert);

                pst3.setString(1,email.trim());
                pst3.setString(2,title.trim());
                pst3.setInt(3,marks);
                pst3.executeUpdate();
            }

        } catch(Exception e){
            System.out.println(e);
        }
    }
}
