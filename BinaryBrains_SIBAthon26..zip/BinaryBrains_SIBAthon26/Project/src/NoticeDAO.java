import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class NoticeDAO {

    // ADD NOTICE (ADMIN/TEACHER)
    public void addNotice(String title,String description){

        try{
            Connection conn=DBConnection.getConnection();

            String query="INSERT INTO notice(title,description) VALUES(?,?)";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,title);
            pst.setString(2,description);

            pst.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }

    // VIEW NOTICE (STUDENT TABLE)
    public void getNotice(DefaultTableModel model){

        try{
            Connection conn=DBConnection.getConnection();

            String query="SELECT title,description FROM notice";
            PreparedStatement pst=conn.prepareStatement(query);
            ResultSet rs=pst.executeQuery();

            model.setRowCount(0);

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString("title"),
                        rs.getString("description")
                });
            }

        } catch(Exception e){
            System.out.println(e);
        }
    }
}

