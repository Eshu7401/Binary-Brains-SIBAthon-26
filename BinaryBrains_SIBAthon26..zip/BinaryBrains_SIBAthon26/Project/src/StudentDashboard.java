import javax.swing.*;
import java.awt.*;

public class StudentDashboard extends JFrame {

    public StudentDashboard(String name,String role,String email){

        setTitle("Student Dashboard");
        setLayout(new BorderLayout());

        // NAVBAR TITLE CENTERED
        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Smart College Management System</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);
        add(navbar,BorderLayout.NORTH);

        // WELCOME MESSAGE ON TOP
        JLabel welcome=new JLabel(
                "<html><div style='padding:10px;font-size:16px;color:#333;text-align:center;'>"+
                        "Welcome "+name+" ("+role+")</div></html>"
        );
        welcome.setHorizontalAlignment(JLabel.CENTER);

        JPanel top=new JPanel(new BorderLayout());
        top.add(navbar,BorderLayout.NORTH);
        top.add(welcome,BorderLayout.SOUTH);

        add(top,BorderLayout.NORTH);

        // MAIN CARD PANEL
        JPanel panel=new JPanel();
        panel.setLayout(new GridLayout(2,3,40,40));
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(60,60,60,60));

        JButton attendance=createCard("View Attendance","#3949AB");
        JButton result=createCard("View Result","#00897B");
        JButton upload=createCard("Upload Assignment","#FB8C00");
        JButton grade=createCard("Assignment Grade","#8E24AA");
        JButton notice=createCard("Notice Board","#D81B60");
        JButton slides=createCard("Study Material","#43A047");

        panel.add(attendance);
        panel.add(result);
        panel.add(upload);
        panel.add(grade);
        panel.add(notice);
        panel.add(slides);

        add(panel,BorderLayout.CENTER);

        // FUNCTIONALITY SAME
        attendance.addActionListener(e->new ViewAttendanceGUI(email));
        result.addActionListener(e->new ViewResultGUI(email));
        upload.addActionListener(e->uploadAssignment(email));
        grade.addActionListener(e->new ViewAssignmentMarksGUI(email));
        notice.addActionListener(e->new ViewNoticeGUI());
        slides.addActionListener(e->new ViewSlidesGUI());

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    JButton createCard(String title,String color){

        JButton btn=new JButton(
                "<html>"+
                        "<div style='"+
                        "background:"+color+";"+
                        "padding:40px;"+
                        "border-radius:15px;"+
                        "color:white;"+
                        "text-align:center;'>"+
                        "<h2>"+title+"</h2>"+
                        "</div></html>"
        );

        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder());
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return btn;
    }

    void uploadAssignment(String email){

        String file=JOptionPane.showInputDialog("Enter Assignment File Path");

        if(file==null || file.trim().equals("")){
            JOptionPane.showMessageDialog(null,"Upload Cancelled");
        }
        else{
            new AssignmentDAO().uploadAssignment(email,file);
            JOptionPane.showMessageDialog(null,"Assignment Uploaded Successfully");
        }
    }
}
