import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewAssignmentMarksGUI extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewAssignmentMarksGUI(String email){

        setTitle("Assignment Marks");
        setLayout(new BorderLayout());

        // NAVBAR
        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Assignment Marks</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);
        add(navbar,BorderLayout.NORTH);

        JPanel panel=new JPanel(new BorderLayout());
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));

        model=new DefaultTableModel(){
            public boolean isCellEditable(int r,int c){
                return false;
            }
        };

        model.addColumn("File");
        model.addColumn("Marks");

        table=new JTable(model);
        table.setRowHeight(25);
        table.setFont(new Font("Arial",Font.PLAIN,14));

        JScrollPane sp=new JScrollPane(table);
        panel.add(sp,BorderLayout.CENTER);

        add(panel,BorderLayout.CENTER);

        // LOAD DATA
        try{
            Connection conn=DBConnection.getConnection();

            String query="SELECT file,marks FROM assignment WHERE email=?";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,email);

            ResultSet rs=pst.executeQuery();

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString("file"),
                        rs.getObject("marks")
                });
            }

        } catch(Exception e){
            System.out.println(e);
        }

        // 🔴 MUST BE AT END
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }
}
