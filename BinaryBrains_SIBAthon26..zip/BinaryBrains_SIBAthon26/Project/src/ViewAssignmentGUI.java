import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class ViewAssignmentGUI extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewAssignmentGUI(){

        setTitle("Submitted Assignments");
        setSize(400,300);
        setLayout(null);

        model=new DefaultTableModel();
        model.addColumn("Email");
        model.addColumn("File");

        table=new JTable(model);
        JScrollPane sp=new JScrollPane(table);
        sp.setBounds(50,50,300,150);
        add(sp);

        try{
            Connection conn=DBConnection.getConnection();
            String query="SELECT email,file FROM assignment";
            PreparedStatement pst=conn.prepareStatement(query);
            ResultSet rs=pst.executeQuery();

            while(rs.next())
                model.addRow(new Object[]{
                        rs.getString("email"),
                        rs.getString("file")
                });

        } catch(Exception e){
            System.out.println(e);
        }

        setVisible(true);
    }
}
