import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ResultUploadGUI extends JFrame {

    JTable table;
    DefaultTableModel model;
    String title;

    public ResultUploadGUI(){

        title=JOptionPane.showInputDialog("Enter Result Title");

        if(title==null || title.trim().equals("")){
            JOptionPane.showMessageDialog(null,"Cancelled");
            dispose();
            return;
        }

        setTitle("Upload/Edit Result : "+title);
        setLayout(new BorderLayout());

        // NAVBAR
        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Upload / Edit Result</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);
        add(navbar,BorderLayout.NORTH);

        // TABLE PANEL
        JPanel panel=new JPanel(new BorderLayout());
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));

        model=new DefaultTableModel(){
            public boolean isCellEditable(int r,int c){
                return c==3; // ONLY MARKS EDITABLE
            }
        };

        model.addColumn("Roll No");
        model.addColumn("Name");
        model.addColumn("Email");
        model.addColumn("Marks");

        table=new JTable(model);
        table.setRowHeight(25);
        table.setFont(new Font("Arial",Font.PLAIN,14));

        JScrollPane sp=new JScrollPane(table);
        panel.add(sp,BorderLayout.CENTER);

        // SAVE BUTTON
        JButton save=new JButton("Save Result");
        save.setFont(new Font("Arial",Font.BOLD,14));
        save.setBackground(new Color(52,152,219));
        save.setForeground(Color.WHITE);
        save.setFocusPainted(false);

        panel.add(save,BorderLayout.SOUTH);

        add(panel,BorderLayout.CENTER);

        save.addActionListener(e->saveResult());

        loadResult();

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    void loadResult(){

        try{
            Connection conn=DBConnection.getConnection();

            String query=
                    "SELECT s.rollno,s.name,s.email,r.marks "+
                            "FROM students s "+
                            "LEFT JOIN result r "+
                            "ON s.email=r.email AND r.title=?";

            PreparedStatement pst=conn.prepareStatement(query);
            pst.setString(1,title.trim());

            ResultSet rs=pst.executeQuery();

            model.setRowCount(0);

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getInt("rollno"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getObject("marks")
                });
            }

        } catch(Exception e){
            System.out.println(e);
        }
    }

    void saveResult(){

        if(table.isEditing()){
            table.getCellEditor().stopCellEditing();
        }

        boolean updated=false;

        for(int i=0;i<table.getRowCount();i++){

            Object marksObj=table.getValueAt(i,3);

            if(marksObj==null || marksObj.toString().trim().equals(""))
                continue;

            String email=table.getValueAt(i,2).toString();
            int marks=Integer.parseInt(marksObj.toString());

            new ResultDAO().saveResult(email,title,marks);
            updated=true;
        }

        if(updated)
            JOptionPane.showMessageDialog(null,"Result Saved Successfully");
        else
            JOptionPane.showMessageDialog(null,"No Marks Entered");
    }
}
