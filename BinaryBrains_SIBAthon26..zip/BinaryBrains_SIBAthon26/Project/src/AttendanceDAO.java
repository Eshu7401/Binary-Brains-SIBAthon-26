import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

class AttendanceDAO {

    // LOAD ATTENDANCE BY DATE (SHOW NAME + EMAIL)
    public void getAttendanceByDate(DefaultTableModel model,String date){

        try{
            Connection conn=DBConnection.getConnection();

            String query=
                    "SELECT s.rollno,s.name,s.email,"+
                            "COALESCE(MAX(a.status='Present'),0) AS present "+
                            "FROM students s "+
                            "LEFT JOIN attendance a "+
                            "ON s.email=a.email AND a.date=? "+
                            "GROUP BY s.rollno,s.name,s.email";

            PreparedStatement pst=conn.prepareStatement(query);
            pst.setString(1,date.trim());

            ResultSet rs=pst.executeQuery();

            model.setRowCount(0);

            while(rs.next()){

                model.addRow(new Object[]{
                        rs.getInt("rollno"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getBoolean("present")
                });
            }

        } catch(Exception e){
            System.out.println(e);
        }
    }




    // INSERT OR UPDATE ATTENDANCE
    public void markAttendance(String email,String date,String status){

        try{
            Connection conn=DBConnection.getConnection();

            String check="SELECT * FROM attendance WHERE email=? AND date=?";
            PreparedStatement pst1=conn.prepareStatement(check);

            pst1.setString(1,email.trim());
            pst1.setString(2,date.trim());

            ResultSet rs=pst1.executeQuery();

            if(rs.next()){

                String update="UPDATE attendance SET status=? WHERE email=? AND date=?";
                PreparedStatement pst2=conn.prepareStatement(update);

                pst2.setString(1,status);
                pst2.setString(2,email.trim());
                pst2.setString(3,date.trim());
                pst2.executeUpdate();
            }
            else{

                String insert="INSERT INTO attendance(email,date,status) VALUES(?,?,?)";
                PreparedStatement pst3=conn.prepareStatement(insert);

                pst3.setString(1,email.trim());
                pst3.setString(2,date.trim());
                pst3.setString(3,status);
                pst3.executeUpdate();
            }

        } catch(Exception e){
            System.out.println(e);
        }
    }
}

