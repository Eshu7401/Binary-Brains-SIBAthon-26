import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewNoticeGUI extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewNoticeGUI(){

        setTitle("View Notices");
        setLayout(new BorderLayout());

        // NAVBAR
        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Notice Board</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);
        add(navbar,BorderLayout.NORTH);

        // TABLE PANEL
        JPanel panel=new JPanel(new BorderLayout());
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));

        model=new DefaultTableModel(){
            public boolean isCellEditable(int r,int c){
                return false;
            }
        };

        model.addColumn("Title");
        model.addColumn("Description");

        table=new JTable(model);
        table.setRowHeight(25);
        table.setFont(new Font("Arial",Font.PLAIN,14));

        JScrollPane sp=new JScrollPane(table);
        panel.add(sp,BorderLayout.CENTER);

        add(panel,BorderLayout.CENTER);

        // LOAD DATA SAME AS BEFORE
        try{
            Connection conn=DBConnection.getConnection();

            String query="SELECT title,description FROM notice";
            PreparedStatement pst=conn.prepareStatement(query);
            ResultSet rs=pst.executeQuery();

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString("title"),
                        rs.getString("description")
                });
            }

        } catch(Exception e){
            System.out.println(e);
        }

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }
}
