import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AttendanceGUI extends JFrame {

    JTable table;
    DefaultTableModel model;
    String date;

    public AttendanceGUI(){

        date=JOptionPane.showInputDialog("Enter Attendance Date");

        if(date==null || date.trim().equals("")){
            JOptionPane.showMessageDialog(null,"Attendance Cancelled");
            dispose();
            return;
        }

        setTitle("Mark Attendance : "+date);
        setLayout(new BorderLayout());

        // NAVBAR
        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Mark Attendance</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);
        add(navbar,BorderLayout.NORTH);

        // TABLE PANEL
        JPanel panel=new JPanel(new BorderLayout());
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));

        model=new DefaultTableModel(){

            public Class getColumnClass(int column){
                if(column==3)
                    return Boolean.class;
                return String.class;
            }
        };

        model.addColumn("Roll No");
        model.addColumn("Name");
        model.addColumn("Email");
        model.addColumn("Present");

        table=new JTable(model);
        table.setRowHeight(25);
        table.setFont(new Font("Arial",Font.PLAIN,14));

        JScrollPane sp=new JScrollPane(table);
        panel.add(sp,BorderLayout.CENTER);

        // SAVE BUTTON
        JButton save=new JButton("Save Attendance");
        save.setFont(new Font("Arial",Font.BOLD,14));
        save.setBackground(new Color(52,152,219));
        save.setForeground(Color.WHITE);
        save.setFocusPainted(false);

        panel.add(save,BorderLayout.SOUTH);

        add(panel,BorderLayout.CENTER);

        save.addActionListener(e->saveAttendance());

        loadAttendance();

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    void loadAttendance(){
        new AttendanceDAO().getAttendanceByDate(model,date);
    }

    void saveAttendance(){

        if(table.isEditing()){
            table.getCellEditor().stopCellEditing();
        }

        for(int i=0;i<table.getRowCount();i++){

            String email=table.getValueAt(i,2).toString();
            boolean present=(boolean)table.getValueAt(i,3);

            String status=present?"Present":"Absent";

            new AttendanceDAO().markAttendance(email,date,status);
        }

        JOptionPane.showMessageDialog(null,"Attendance Saved Successfully");
    }
}
