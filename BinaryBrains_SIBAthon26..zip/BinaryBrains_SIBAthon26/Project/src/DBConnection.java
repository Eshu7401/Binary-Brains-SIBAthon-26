import java.sql.*;

public class DBConnection {

    static Connection conn;

    public static Connection getConnection(){

        try{
            conn=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/scms",
                    "root",
                    "RadheRadhe2"
            );
        } catch(Exception e){
            System.out.println(e);
        }
        return conn;
    }
}
