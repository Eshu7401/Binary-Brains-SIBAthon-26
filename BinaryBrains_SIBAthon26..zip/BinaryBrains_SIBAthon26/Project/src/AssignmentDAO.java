import java.sql.*;

public class AssignmentDAO {

    public void uploadAssignment(String email,String file){

        try{
            Connection conn=DBConnection.getConnection();

            String query="INSERT INTO assignment(email,file) VALUES(?,?)";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,email.trim());
            pst.setString(2,file.trim());

            pst.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }


    public void gradeAssignment(String email,String file,int marks){

        try{
            Connection conn=DBConnection.getConnection();

            String query="UPDATE assignment SET marks=? WHERE email=? AND file=?";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setInt(1,marks);
            pst.setString(2,email.trim());
            pst.setString(3,file.trim());

            pst.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }


}
