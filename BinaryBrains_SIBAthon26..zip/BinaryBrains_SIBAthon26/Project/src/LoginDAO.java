import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDAO {

    public String[] login(String email,String password){

        String data[]=null;

        try{

            Connection conn=DBConnection.getConnection();

            String query=
                    "SELECT name,role,email "+
                            "FROM users "+
                            "WHERE TRIM(email)=? AND TRIM(password)=?";

            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,email.trim());
            pst.setString(2,password.trim());

            ResultSet rs=pst.executeQuery();

            if(rs.next()){

                data=new String[3];
                data[0]=rs.getString("name");
                data[1]=rs.getString("role");
                data[2]=rs.getString("email");
            }

        } catch(Exception e){
            System.out.println(e);
        }

        return data;
    }
}
