import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewAttendanceGUI extends JFrame {

    JTable table;
    DefaultTableModel model;

    public ViewAttendanceGUI(String email){

        setTitle("View Attendance");
        setLayout(new BorderLayout());

        // NAVBAR
        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Attendance Record</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);
        add(navbar,BorderLayout.NORTH);

        // TABLE PANEL
        JPanel panel=new JPanel(new BorderLayout());
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));

        model=new DefaultTableModel(){
            public boolean isCellEditable(int r,int c){
                return false;
            }
        };

        model.addColumn("Date");
        model.addColumn("Status");

        table=new JTable(model);
        table.setRowHeight(25);
        table.setFont(new Font("Arial",Font.PLAIN,14));

        JScrollPane sp=new JScrollPane(table);
        panel.add(sp,BorderLayout.CENTER);

        add(panel,BorderLayout.CENTER);

        // LOAD DATA SAME AS BEFORE
        try{
            Connection conn=DBConnection.getConnection();

            String query="SELECT date,status FROM attendance WHERE email=?";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,email);

            ResultSet rs=pst.executeQuery();

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString("date"),
                        rs.getString("status")
                });
            }

        } catch(Exception e){
            System.out.println(e);
        }

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }
}
