import java.sql.*;

public class StudentDAO {

    public void addStudent(String name,String email,String password){

        try{
            Connection conn=DBConnection.getConnection();

            // LOGIN ENTRY
            String q1="INSERT INTO users(name,email,password,role) VALUES(?,?,?,'Student')";
            PreparedStatement pst1=conn.prepareStatement(q1);

            pst1.setString(1,name.trim());
            pst1.setString(2,email.trim());
            pst1.setString(3,password.trim());
            pst1.executeUpdate();

            // ROLLNO ENTRY
            String q2="INSERT INTO students(name,email,password,enroll_date) VALUES(?,?,?,CURDATE())";
            PreparedStatement pst2=conn.prepareStatement(q2);

            pst2.setString(1,name.trim());
            pst2.setString(2,email.trim());
            pst2.setString(3,password.trim());
            pst2.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }

    public void deleteStudent(String email){

        try{
            Connection conn=DBConnection.getConnection();

            String q1="DELETE FROM users WHERE email=? AND role='Student'";
            PreparedStatement pst1=conn.prepareStatement(q1);
            pst1.setString(1,email.trim());
            pst1.executeUpdate();

            String q2="DELETE FROM students WHERE email=?";
            PreparedStatement pst2=conn.prepareStatement(q2);
            pst2.setString(1,email.trim());
            pst2.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }
}
