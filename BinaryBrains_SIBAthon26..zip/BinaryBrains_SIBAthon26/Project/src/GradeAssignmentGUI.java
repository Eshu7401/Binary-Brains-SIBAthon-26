import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GradeAssignmentGUI extends JFrame {

    JTable table;
    DefaultTableModel model;

    public GradeAssignmentGUI(){

        setTitle("Assignment Marks");
        setLayout(new BorderLayout());

        // NAVBAR
        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Assignment Grading</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);
        add(navbar,BorderLayout.NORTH);

        JPanel panel=new JPanel(new BorderLayout());
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));

        model=new DefaultTableModel(){
            public boolean isCellEditable(int r,int c){
                return c==2;
            }
        };

        model.addColumn("Email");
        model.addColumn("File");
        model.addColumn("Marks");

        table=new JTable(model);
        table.setRowHeight(25);
        table.setFont(new Font("Arial",Font.PLAIN,14));

        JScrollPane sp=new JScrollPane(table);
        panel.add(sp,BorderLayout.CENTER);

        JButton save=new JButton("Save Marks");
        save.setFont(new Font("Arial",Font.BOLD,14));
        save.setBackground(new Color(52,152,219));
        save.setForeground(Color.WHITE);

        panel.add(save,BorderLayout.SOUTH);

        add(panel,BorderLayout.CENTER);

        save.addActionListener(e->saveMarks());

        loadAssignments();

        // 🔴 THIS WAS MISSING BEFORE
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    void loadAssignments(){

        try{
            Connection conn=DBConnection.getConnection();

            String query="SELECT email,file,marks FROM assignment";
            PreparedStatement pst=conn.prepareStatement(query);
            ResultSet rs=pst.executeQuery();

            model.setRowCount(0);

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString("email"),
                        rs.getString("file"),
                        rs.getObject("marks")
                });
            }

        } catch(Exception e){
            System.out.println(e);
        }
    }

    void saveMarks(){

        if(table.isEditing()){
            table.getCellEditor().stopCellEditing();
        }

        boolean updated=false;

        for(int i=0;i<table.getRowCount();i++){

            Object marksObj=table.getValueAt(i,2);

            if(marksObj==null || marksObj.toString().trim().equals(""))
                continue;

            String email=table.getValueAt(i,0).toString();
            String file=table.getValueAt(i,1).toString();

            int marks=Integer.parseInt(marksObj.toString());

            new AssignmentDAO().gradeAssignment(email,file,marks);
            updated=true;
        }

        if(updated)
            JOptionPane.showMessageDialog(null,"Marks Updated Successfully");
        else
            JOptionPane.showMessageDialog(null,"No Marks Entered");

        loadAssignments();
    }
}
