import javax.swing.*;
import java.awt.*;

public class TeacherDashboard extends JFrame {

    public TeacherDashboard(String name,String role,String email){

        setTitle("Teacher Dashboard");
        setLayout(new BorderLayout());

        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Smart College Management System</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);

        JLabel welcome=new JLabel(
                "<html><div style='padding:10px;font-size:16px;color:#333;text-align:center;'>"+
                        "Welcome "+name+" ("+role+")</div></html>"
        );
        welcome.setHorizontalAlignment(JLabel.CENTER);

        JPanel top=new JPanel(new BorderLayout());
        top.add(navbar,BorderLayout.NORTH);
        top.add(welcome,BorderLayout.SOUTH);

        add(top,BorderLayout.NORTH);

        JPanel panel=new JPanel(new GridLayout(2,3,40,40));
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(60,60,60,60));

        JButton attendance=createCard("Mark Attendance","#3949AB");
        JButton assignment=createCard("Grade Assignments","#00897B");
        JButton slides=createCard("Upload Slides","#FB8C00");
        JButton result=createCard("Upload Result","#8E24AA");
        JButton notice=createCard("Upload Notice","#D81B60");

        panel.add(attendance);
        panel.add(assignment);
        panel.add(slides);
        panel.add(result);
        panel.add(notice);

        add(panel,BorderLayout.CENTER);

        attendance.addActionListener(e->new AttendanceGUI());
        assignment.addActionListener(e->new GradeAssignmentGUI());
        result.addActionListener(e->new ResultUploadGUI());

        // SAFE SLIDES
        slides.addActionListener(e->{

            String title=JOptionPane.showInputDialog("Enter Slide Title");
            if(title==null || title.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Upload Cancelled");
                return;
            }

            String file=JOptionPane.showInputDialog("Enter File Path");
            if(file==null || file.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Upload Cancelled");
                return;
            }

            new SlidesDAO().uploadSlides(title.trim(),file.trim());
            JOptionPane.showMessageDialog(null,"Slides Uploaded Successfully");
        });

        // SAFE NOTICE
        notice.addActionListener(e->{

            String title=JOptionPane.showInputDialog("Enter Notice Title");
            if(title==null || title.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Notice Upload Cancelled");
                return;
            }

            String desc=JOptionPane.showInputDialog("Enter Notice Description");
            if(desc==null || desc.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Notice Upload Cancelled");
                return;
            }

            new NoticeDAO().addNotice(title.trim(),desc.trim());
            JOptionPane.showMessageDialog(null,"Notice Uploaded Successfully");
        });

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    JButton createCard(String title,String color){

        JButton btn=new JButton(
                "<html><div style='background:"+color+";padding:40px;border-radius:15px;color:white;text-align:center;'>"+
                        "<h2>"+title+"</h2></div></html>"
        );

        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder());
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return btn;
    }
}
