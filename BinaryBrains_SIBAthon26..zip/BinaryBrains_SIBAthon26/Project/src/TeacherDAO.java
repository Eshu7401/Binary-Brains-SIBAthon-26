import java.sql.*;

public class TeacherDAO {

    public void addTeacher(String name,String email,String password){

        try{
            Connection conn=DBConnection.getConnection();

            String query="INSERT INTO users(name,email,password,role) VALUES(?,?,?,'Teacher')";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,name);
            pst.setString(2,email);
            pst.setString(3,password);

            pst.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }

    public void deleteTeacher(String email){

        try{
            Connection conn=DBConnection.getConnection();

            String query="DELETE FROM users WHERE email=? AND role='Teacher'";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,email);
            pst.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }
}
