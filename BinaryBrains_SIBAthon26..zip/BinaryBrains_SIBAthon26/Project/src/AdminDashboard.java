import javax.swing.*;
import java.awt.*;

public class AdminDashboard extends JFrame {

    public AdminDashboard(String name,String role,String email){

        setTitle("Admin Dashboard");
        setLayout(new BorderLayout());

        JLabel navbar=new JLabel(
                "<html><div style='background:#1A237E;padding:15px;color:white;font-size:22px;text-align:center;'>"+
                        "Smart College Management System</div></html>"
        );
        navbar.setHorizontalAlignment(JLabel.CENTER);

        JLabel welcome=new JLabel(
                "<html><div style='padding:10px;font-size:16px;color:#333;text-align:center;'>"+
                        "Welcome "+name+" ("+role+")</div></html>"
        );
        welcome.setHorizontalAlignment(JLabel.CENTER);

        JPanel top=new JPanel(new BorderLayout());
        top.add(navbar,BorderLayout.NORTH);
        top.add(welcome,BorderLayout.SOUTH);

        add(top,BorderLayout.NORTH);

        JPanel panel=new JPanel(new GridLayout(2,3,40,40));
        panel.setBackground(new Color(245,245,245));
        panel.setBorder(BorderFactory.createEmptyBorder(60,60,60,60));

        JButton addStudent=createCard("Add Student","#3949AB");
        JButton deleteStudent=createCard("Delete Student","#00897B");
        JButton addTeacher=createCard("Add Teacher","#FB8C00");
        JButton deleteTeacher=createCard("Delete Teacher","#8E24AA");
        JButton notice=createCard("Upload Notice","#D81B60");

        panel.add(addStudent);
        panel.add(deleteStudent);
        panel.add(addTeacher);
        panel.add(deleteTeacher);
        panel.add(notice);

        add(panel,BorderLayout.CENTER);

        // SAFE ADD STUDENT
        addStudent.addActionListener(e->{

            String n=JOptionPane.showInputDialog("Enter Name");
            if(n==null || n.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            String em=JOptionPane.showInputDialog("Enter Email");
            if(em==null || em.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            String p=JOptionPane.showInputDialog("Enter Password");
            if(p==null || p.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            new StudentDAO().addStudent(n.trim(),em.trim(),p.trim());
            JOptionPane.showMessageDialog(null,"Student Added Successfully");
        });

        // SAFE DELETE STUDENT
        deleteStudent.addActionListener(e->{

            String em=JOptionPane.showInputDialog("Enter Email to Delete");
            if(em==null || em.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            new StudentDAO().deleteStudent(em.trim());
            JOptionPane.showMessageDialog(null,"Student Deleted Successfully");
        });

        // SAFE ADD TEACHER
        addTeacher.addActionListener(e->{

            String n=JOptionPane.showInputDialog("Enter Name");
            if(n==null || n.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            String em=JOptionPane.showInputDialog("Enter Email");
            if(em==null || em.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            String p=JOptionPane.showInputDialog("Enter Password");
            if(p==null || p.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            new TeacherDAO().addTeacher(n.trim(),em.trim(),p.trim());
            JOptionPane.showMessageDialog(null,"Teacher Added Successfully");
        });

        // SAFE DELETE TEACHER
        deleteTeacher.addActionListener(e->{

            String em=JOptionPane.showInputDialog("Enter Email to Delete");
            if(em==null || em.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Cancelled");
                return;
            }

            new TeacherDAO().deleteTeacher(em.trim());
            JOptionPane.showMessageDialog(null,"Teacher Deleted Successfully");
        });

        // SAFE NOTICE UPLOAD
        notice.addActionListener(e->{

            String title=JOptionPane.showInputDialog("Enter Notice Title");
            if(title==null || title.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Notice Upload Cancelled");
                return;
            }

            String desc=JOptionPane.showInputDialog("Enter Notice Description");
            if(desc==null || desc.trim().equals("")){
                JOptionPane.showMessageDialog(null,"Notice Upload Cancelled");
                return;
            }

            new NoticeDAO().addNotice(title.trim(),desc.trim());
            JOptionPane.showMessageDialog(null,"Notice Uploaded Successfully");
        });

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    JButton createCard(String title,String color){

        JButton btn=new JButton(
                "<html><div style='background:"+color+";padding:40px;border-radius:15px;color:white;text-align:center;'>"+
                        "<h2>"+title+"</h2></div></html>"
        );

        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder());
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return btn;
    }
}
