import java.sql.*;

public class SlidesDAO {

    public void uploadSlides(String title,String file){

        try{
            Connection conn=DBConnection.getConnection();

            String query="INSERT INTO slides(title,file) VALUES(?,?)";
            PreparedStatement pst=conn.prepareStatement(query);

            pst.setString(1,title);
            pst.setString(2,file);

            pst.executeUpdate();

        } catch(Exception e){
            System.out.println(e);
        }
    }
}
